﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Road_to_Recovery_1
{
    public partial class MaintainEmployee : Form
    {
        public string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Uni\Y2\Semester2\Cmpg223\Project\Road to Recovery 1\Road to Recovery 1\ds.mdf"";Integrated Security=True";
        public MaintainEmployee()
        {
            InitializeComponent();
        }

        private void buttonRead_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string query = "SELECT * FROM tblUser";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(reader);

            dataGridViewEmployees.DataSource = dataTable;
        }

        private void buttonInsert_Click(object sender, EventArgs e)
        {



        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            Update_employees update_ = new Update_employees();
            update_.Show();
        }
    }
}
