﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Road_to_Recovery_1
{
    public partial class Maintain : Form
    {
        private Form activeChildForm = null;
        public Maintain()
        {
            InitializeComponent();
        }

        private void maintainMedicatToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void maintainUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseActiveChildForm();
            Maintain_users editForm = new Maintain_users();
            editForm.MdiParent = this;
            editForm.Show();
            activeChildForm = editForm;
        }
        private void CloseActiveChildForm()
        {
            if (activeChildForm != null)
            {
                activeChildForm.Close();
                activeChildForm = null;
            }
        }

        private void maintainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseActiveChildForm();
            MaintainEmployee editForm = new MaintainEmployee();
            editForm.MdiParent = this;
            editForm.Show();
            activeChildForm = editForm;
        }

        private void welcomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseActiveChildForm();
            EmployeeInformation editForm = new EmployeeInformation();
            editForm.MdiParent = this;
            editForm.Show();
            activeChildForm = editForm;
        }
    }
}
