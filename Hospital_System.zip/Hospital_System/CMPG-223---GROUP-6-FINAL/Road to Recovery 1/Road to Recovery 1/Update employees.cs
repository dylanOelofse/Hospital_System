﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Road_to_Recovery_1
{
    public partial class Update_employees : Form
    {
        public string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Uni\Y2\Semester2\Cmpg223\Project\Road to Recovery 1\Road to Recovery 1\ds.mdf"";Integrated Security=True";
        public Update_employees()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Update_employees_Load(object sender, EventArgs e)
        {
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string employeeName = textBoxEmplName.Text;
            string dob = textBoxDOB.Text;
            string email = textBoxUserEmail.Text;
            string roleName = comboBoxRole.Text;

            int? roleId = GetRoleIdByName(roleName);
            if (roleId == null)
            {
                MessageBox.Show("Invalid role selected. Please choose a valid role.", "Update Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                string updateEmployeeQuery = "UPDATE [tblEmployees] SET Employee_Name = @EmployeeName, Employee_DOB = @DOB, Role_Id = @RoleId WHERE User_Email = @Email";
                SqlCommand updateEmployeeCommand = new SqlCommand(updateEmployeeQuery, connection);

                updateEmployeeCommand.Parameters.AddWithValue("@EmployeeName", employeeName);
                updateEmployeeCommand.Parameters.AddWithValue("@DOB", dob);
                updateEmployeeCommand.Parameters.AddWithValue("@RoleId", roleId.Value);
                updateEmployeeCommand.Parameters.AddWithValue("@Email", email);

                int rowsAffected = updateEmployeeCommand.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Employee updated successfully.", "Update Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed to update employee. Please ensure you entered correct email.", "Update Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private int? GetRoleIdByName(string roleName)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT Role_Id FROM tblRole WHERE Role_Permission = @RoleName";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@RoleName", roleName);

                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null)
                {
                    return (int)result;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
    

