﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Road_to_Recovery_1
{
    public partial class EmployeeInformation : Form
    {
        public string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Uni\Y2\Semester2\Cmpg223\Project\Road to Recovery 1\Road to Recovery 1\ds.mdf"";Integrated Security=True";
        public EmployeeInformation()
        {
            InitializeComponent();
        }
        private int? GetRoleIdByName(string roleName)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT Role_Id FROM [tblRole] WHERE Role_Permission = @RoleName";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@RoleName", roleName);

                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null)
                    return (int)result;
                else
                    return null;
            }
        }

        private int? GetUserIdByEmail(string email)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT User_Id FROM [tblUser] WHERE User_Email = @Email";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);

                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null)
                    return (int)result;
                else
                    return null;
            }

        }

        private void buttonInsertInfo_Click(object sender, EventArgs e)
        {
            string EmployeeName = textBoxEmplName.Text;
            string DOB = textBoxDOB.Text;
            string email = textBoxUserEmail.Text;
            string role = comboBoxRole.Text;

            if (string.IsNullOrWhiteSpace(EmployeeName) || string.IsNullOrWhiteSpace(DOB) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(role))
            {
                MessageBox.Show("All fields are required!");
                return;
            }

            AddEmployee(email, EmployeeName, DOB, role);
        }
        private int GetNextEmployeeId()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT ISNULL(MAX(Employee_Id), 0) + 1 FROM [tblEmployees]";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                return (int)command.ExecuteScalar();
            }
        }



        public void AddEmployee(string email, string employeeName, string DOB, string role)
        {
            int? userId = GetUserIdByEmail(email);
            if (userId == null)
            {
                MessageBox.Show("No user found with the provided email.");
                return;
            }

            int? roleId = GetRoleIdByName(role);
            if (roleId == null)
            {
                MessageBox.Show("Invalid role name provided.");
                return;
            }

            int nextEmployeeId = GetNextEmployeeId(); // Fetch next available Employee_Id

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "INSERT INTO [tblEmployees] (Employee_Id, Employee_Name, Employee_DOB, User_Id, Role_Id) VALUES (@EmployeeId, @EmployeeName, @DOB, @UserId, @RoleId)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@EmployeeId", nextEmployeeId);
                command.Parameters.AddWithValue("@EmployeeName", employeeName);
                command.Parameters.AddWithValue("@DOB", DOB);
                command.Parameters.AddWithValue("@UserId", userId.Value);
                command.Parameters.AddWithValue("@RoleId", roleId.Value);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Employee added successfully!");
                }
                else
                {
                    MessageBox.Show("Failed to add employee.");
                }
            }
        }
    }
}



