﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Road_to_Recovery_1
{
    public partial class UpdateUsers : Form
    {
        public string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Uni\Y2\Semester2\Cmpg223\Project\Road to Recovery 1\Road to Recovery 1\ds.mdf"";Integrated Security=True";
        public UpdateUsers()
        {
            InitializeComponent();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string password = textBoxpassword.Text;
            string email = textBoxEmail.Text;
            string roleName = comboBoxRoleUpdate.Text; // I'm assuming textBoxNumber contains the role name now

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                // Step 1: Fetch RoleId based on roleName from Roles table
                string getRoleIdQuery = "SELECT Role_Id FROM tblRole WHERE Role_Permission = @RoleName";
                SqlCommand getRoleIdCommand = new SqlCommand(getRoleIdQuery, connection);
                getRoleIdCommand.Parameters.AddWithValue("@RoleName", roleName);

                object roleIdObj = getRoleIdCommand.ExecuteScalar();

                // If roleId is null, it means the role doesn't exist
                if (roleIdObj == null)
                {
                    MessageBox.Show("Invalid role name. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int roleId = Convert.ToInt32(roleIdObj);

                // Step 2: Update the User4 table with this RoleId
                string updateQuery = "UPDATE [tblUser] SET User_Password = @Password,  Role_id= @RoleId WHERE User_Email = @Email";
                SqlCommand updateCommand = new SqlCommand(updateQuery, connection);


                updateCommand.Parameters.AddWithValue("@Email", email);
                updateCommand.Parameters.AddWithValue("@Password", password);
                updateCommand.Parameters.AddWithValue("@RoleId", roleId);

                int rowsAffected = updateCommand.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Profile updated successfully.", "Update Profile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed to update profile. Please try again.", "Update Profile", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
