﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Road_to_Recovery_1
{
    public partial class LoginFom : Form
    {
        SqlCommand comm;
        SqlConnection conn;
        public const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Uni\Y2\Semester2\Cmpg223\Project\Road to Recovery 1\Road to Recovery 1\ds.mdf"";Integrated Security=True";
        public LoginFom()
        {
            InitializeComponent();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            string email = textBoxEmailRegister.Text;
            string password = textBoxPasswordRegister.Text;
            string roleName = comboBoxRoles.Text;

            // Fetch role ID using role name
            int? roleId = GetRoleIdByName(roleName);

            if (roleId == null)
            {
                MessageBox.Show("Invalid role name provided!");
                return;
            }

            int nextUserId = GetNextUserId();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "INSERT INTO [tblUser] (User_Id, User_Email, User_Password, Role_Id) VALUES (@UserId, @Email, @Password, @RoleId)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@UserId", nextUserId);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Password", password); // Storing passwords in plaintext is NOT secure!
                command.Parameters.AddWithValue("@RoleId", roleId);

                connection.Open();
                command.ExecuteNonQuery();

                MessageBox.Show("Registration successful! You can now sign in with your credentials.");
            }
        }

        private int GetNextUserId()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT ISNULL(MAX(User_Id), 0) + 1 FROM [tblUser]";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                return (int)command.ExecuteScalar();
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string email = textBoxEmailLogin.Text;
            string password = textBoxPasswordLogin.Text;
            string roleName = comboBoxRoleLogin.Text;  // Changed to roleName for clarity.

            bool isValidUser = AuthenticateUser(email, password, roleName);

            if (isValidUser)
            {
                // Successful login, perform any further actions, e.g., open a new form or dashboard
                MessageBox.Show("Login successful!");
                 Maintain maintain = new Maintain();
                 maintain.Show();
            }
            else
            {
                MessageBox.Show("Invalid email, password, or role. Please try again.");
            }
        }

        private bool AuthenticateUser(string email, string password, string roleName)
        {
            int? roleId = GetRoleIdByName(roleName);

            if (roleId == null)
            {
                MessageBox.Show("Invalid role name provided!");
                return false;
            }

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT COUNT(*) FROM [tblUser] WHERE User_Email = @Email AND User_Password = @Password AND Role_Id = @RoleId";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Password", password);  // Warning: Storing and comparing passwords in plaintext is insecure!
                command.Parameters.AddWithValue("@RoleId", roleId);

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count > 0;  // If count is more than 0, it means a matching record is found
            }
        }

        private int? GetRoleIdByName(string roleName)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT Role_Id FROM [tblRole] WHERE Role_Permission = @RoleName";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@RoleName", roleName);

                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null)
                {
                    return (int)result;
                }
                else
                {
                    return null;
                }
            }
        }

        private void LoadRolesIntoComboBox()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                string query = "SELECT Role_Permission FROM [tblRole]";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    comboBoxRoleLogin.Items.Add(reader["Role_Permission"].ToString());
                }

                reader.Close();
            }
        }
    }
}
