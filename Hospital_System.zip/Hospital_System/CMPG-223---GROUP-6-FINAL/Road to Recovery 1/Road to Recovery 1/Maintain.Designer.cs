﻿namespace Road_to_Recovery_1
{
    partial class Maintain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.welcomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintainClientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintainMedicatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintainUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.welcomeToolStripMenuItem,
            this.maintainToolStripMenuItem,
            this.maintainClientsToolStripMenuItem,
            this.maintainMedicatToolStripMenuItem,
            this.maintainUsersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // welcomeToolStripMenuItem
            // 
            this.welcomeToolStripMenuItem.Name = "welcomeToolStripMenuItem";
            this.welcomeToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.welcomeToolStripMenuItem.Text = "Welcome";
            this.welcomeToolStripMenuItem.Click += new System.EventHandler(this.welcomeToolStripMenuItem_Click);
            // 
            // maintainToolStripMenuItem
            // 
            this.maintainToolStripMenuItem.Name = "maintainToolStripMenuItem";
            this.maintainToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.maintainToolStripMenuItem.Text = "Maintain employees";
            this.maintainToolStripMenuItem.Click += new System.EventHandler(this.maintainToolStripMenuItem_Click);
            // 
            // maintainClientsToolStripMenuItem
            // 
            this.maintainClientsToolStripMenuItem.Name = "maintainClientsToolStripMenuItem";
            this.maintainClientsToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.maintainClientsToolStripMenuItem.Text = "Maintain Clients";
            // 
            // maintainMedicatToolStripMenuItem
            // 
            this.maintainMedicatToolStripMenuItem.Name = "maintainMedicatToolStripMenuItem";
            this.maintainMedicatToolStripMenuItem.Size = new System.Drawing.Size(129, 20);
            this.maintainMedicatToolStripMenuItem.Text = "Maintain medication";
            this.maintainMedicatToolStripMenuItem.Click += new System.EventHandler(this.maintainMedicatToolStripMenuItem_Click);
            // 
            // maintainUsersToolStripMenuItem
            // 
            this.maintainUsersToolStripMenuItem.Name = "maintainUsersToolStripMenuItem";
            this.maintainUsersToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.maintainUsersToolStripMenuItem.Text = "Maintain users";
            this.maintainUsersToolStripMenuItem.Click += new System.EventHandler(this.maintainUsersToolStripMenuItem_Click);
            // 
            // Maintain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Maintain";
            this.Text = "Maintian";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem welcomeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintainClientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintainMedicatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintainUsersToolStripMenuItem;
    }
}